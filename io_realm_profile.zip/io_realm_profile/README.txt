IO — ENTER THE REALM
====================

FILES
- index.html: profile page
- pfp.jpg: your uploaded profile picture
- addiction.mp3: optional audio file you provide

RUN
1. Keep index.html and pfp.jpg in the same folder.
2. To enable music, place a legally obtained audio file named addiction.mp3 in this folder.
3. Open index.html in a modern browser. For best results, run a local server or upload the folder to a static host.

NOTES
- The profile starts behind an “Enter the realm” gate.
- Music is attempted after the visitor clicks the gate. Browsers may block playback if the audio file is missing.
- The animated cyberpunk/night background uses a remote Unsplash image and therefore needs an internet connection.
- Comic Sans is preferred, with Comic Neue as a web-font fallback.
- The ring cursor is enabled on desktop and hidden on touch/mobile screens.
